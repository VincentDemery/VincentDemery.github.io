#!/bin/bash

VMD_COMMAND=.vmd_command.sh
VMD_DISPLAY=.vmd_display.tcl

gzip -qdf *.gz

echo "mol modstyle 0 0 Beads 3.000000 12.000000" > $VMD_DISPLAY
echo "mol modselect 0 0 all z>0 and z<12" >> $VMD_DISPLAY   
echo "mol selupdate 0 0 1" >> $VMD_DISPLAY
echo "menu main on" >> $VMD_DISPLAY

echo -n vmd -f > $VMD_COMMAND;for i in dump*; do echo -n " -lammpstrj $i" >> $VMD_COMMAND; done;
echo " -startup $VMD_DISPLAY" >> $VMD_COMMAND

bash $VMD_COMMAND
